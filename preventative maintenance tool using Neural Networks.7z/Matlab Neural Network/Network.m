% data_initial pre-loaded data file in form of matrix for 3 classes
load data_initial;

% training data handling in diverse manner for better training perfoemance
training_data1 = [class1(:,[1:4]), class2(:,[1:4]),class3(:,[1:4])];
training_data2 = [class1(:,[7:13]), class2(:,[7:13]),class3(:,[7:13])];
training_data3 = [class1(:,[16:end]), class2(:,[16:end]),class3(:,[16:end])];

% final traing as 
training_data= [training_data1,training_data2,training_data3];

%test data
test_data=[class1(:,[5:6 14:15]), class2(:,[5:6 14:15]), class3(:,[5:6 14:15])];

%target data
target_data1= [zeros(1,8) ones(1,4); zeros(1,4) ones(1,4) zeros(1,4) ];
target_data2= [zeros(1,14) ones(1,7); zeros(1,7) ones(1,14)];
target_data3= [zeros(1,18) ones(1,9); zeros(1,9) ones(1,18)];
target_data = [target_data1,target_data2,target_data3];

%create feedforward network
mynet = feedforwardnet([100 50 10 ],'trainlm');
mynet.layers{1}.transferFcn='purelin';
mynet.layers{2}.transferFcn='tansig';
mynet.layers{3}.transferFcn='purelin';
mynet.layers{4}.transferFcn='tansig';
mynet=init(mynet);
mynet = train(mynet,training_data,target_data);
sim(mynet,test_data);